<?php

namespace App\Filament\Resources\BusinessResource\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class BusinessOverview extends BaseWidget
{
    protected function getStats(): array
    {
        return [
            //
        ];
    }
}
